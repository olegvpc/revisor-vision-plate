from django.apps import AppConfig


class PlatesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plates'
